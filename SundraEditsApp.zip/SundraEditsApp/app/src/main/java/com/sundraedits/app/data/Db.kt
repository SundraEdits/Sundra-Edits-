package com.sundraedits.app.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

/** All money is stored in minor units (paise/cents) to avoid rounding errors. */
@Entity(tableName = "clients")
data class Client(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "invoices", indices = [Index(value = ["number"], unique = true)])
data class Invoice(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val number: String,
    val clientId: Long,
    val currency: String,      // "INR" or "USD"
    val totalMinor: Long,
    val status: String,        // Draft, Pending, Partial, Paid, Overdue, Cancelled
    val issueDate: Long,
    val dueDate: Long
)

@Entity(tableName = "payments")
data class Payment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val invoiceId: Long,
    val amountMinor: Long,
    val currency: String,
    val date: Long
)

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val amountMinor: Long,
    val currency: String,
    val date: Long
)

@Dao interface ClientDao { @Query("SELECT * FROM clients") fun all(): Flow<List<Client>> }
@Dao interface InvoiceDao { @Query("SELECT * FROM invoices ORDER BY issueDate DESC") fun all(): Flow<List<Invoice>> }
@Dao interface PaymentDao { @Query("SELECT * FROM payments ORDER BY date DESC") fun all(): Flow<List<Payment>> }
@Dao interface ExpenseDao { @Query("SELECT * FROM expenses ORDER BY date DESC") fun all(): Flow<List<Expense>> }

@Database(
    entities = [Client::class, Invoice::class, Payment::class, Expense::class],
    version = 1, exportSchema = false
)
abstract class AppDb : RoomDatabase() {
    abstract fun clients(): ClientDao
    abstract fun invoices(): InvoiceDao
    abstract fun payments(): PaymentDao
    abstract fun expenses(): ExpenseDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "sundra.db")
                .build().also { inst = it }
        }
    }
}
