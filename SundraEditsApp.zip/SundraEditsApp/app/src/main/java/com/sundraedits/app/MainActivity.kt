package com.sundraedits.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sundraedits.app.ui.DashboardViewModel
import com.sundraedits.app.ui.Stats
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

private val Gold = Color(0xFFB8975A)
private val Light = lightColorScheme(
    primary = Gold, background = Color(0xFFFAF7F0), surface = Color(0xFFFFFDF8),
    onBackground = Color(0xFF2B2B2B), onSurface = Color(0xFF2B2B2B)
)
private val Dark = darkColorScheme(
    primary = Gold, background = Color(0xFF1C1B19), surface = Color(0xFF262421),
    onBackground = Color(0xFFEDE8DC), onSurface = Color(0xFFEDE8DC)
)

private val modules = listOf(
    "Dashboard", "Invoices", "Clients", "Services", "Payments",
    "Expenses", "Quotations", "Analytics", "Recycle Bin", "Settings"
)

class MainActivity : ComponentActivity() {
    private val vm: DashboardViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light) {
                App(vm)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun App(vm: DashboardViewModel) {
    var current by remember { mutableStateOf("Dashboard") }
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    BackHandler(enabled = drawer.isOpen || current != "Dashboard") {
        if (drawer.isOpen) scope.launch { drawer.close() } else current = "Dashboard"
    }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet {
                Text("SUNDRA EDITS", Modifier.padding(24.dp, 28.dp, 24.dp, 4.dp),
                    fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Text("Your Vision. Our Creativity.", Modifier.padding(24.dp, 0.dp, 24.dp, 16.dp),
                    fontSize = 12.sp, color = Gold)
                modules.forEach { m ->
                    NavigationDrawerItem(
                        label = { Text(m) }, selected = m == current,
                        onClick = { current = m; scope.launch { drawer.close() } },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                }
            }
        }
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    title = { Text(current) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawer.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Menu")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background)
                )
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                if (current == "Dashboard") Dashboard(vm)
                else NotBuilt(current)
            }
        }
    }
}

@Composable
private fun NotBuilt(name: String) {
    Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text(name, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text("Not built yet. This module is scheduled for a later phase.")
    }
}

private fun money(minor: Long, cur: String): String {
    val nf = NumberFormat.getNumberInstance(if (cur == "INR") Locale("en", "IN") else Locale.US)
    nf.minimumFractionDigits = 2; nf.maximumFractionDigits = 2
    return (if (cur == "INR") "₹" else "$") + nf.format(minor / 100.0)
}

@Composable
private fun Dashboard(vm: DashboardViewModel) {
    val s by vm.stats.collectAsStateWithLifecycle()
    val cur by vm.selected.collectAsStateWithLifecycle()
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("INR", "USD").forEach { c ->
                    FilterChip(selected = cur == c, onClick = { vm.select(c) }, label = { Text(c) })
                }
            }
        }
        val cards = listOf(
            "Total Revenue" to money(s.revenue, cur),
            "Outstanding Payments" to money(s.outstanding, cur),
            "Total Expenses" to money(s.expenses, cur),
            "Net Profit" to money(s.net, cur),
            "Total Invoices" to s.totalInvoices.toString(),
            "Paid Invoices" to s.paid.toString(),
            "Pending Invoices" to s.pending.toString(),
            "Overdue Invoices" to s.overdue.toString()
        )
        items(cards) { (label, value) -> StatCard(label, value) }
        item {
            Text("No records yet. Charts and recent activity will appear here once " +
                "invoices and payments can be created (next phase).",
                fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
        }
    }
}

@Composable
private fun StatCard(label: String, value: String) {
    Surface(
        shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp, shadowElevation = 2.dp,
        border = BorderStroke(0.5.dp, Gold.copy(alpha = 0.35f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(18.dp)) {
            Text(label, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
            Spacer(Modifier.height(4.dp))
            Text(value, fontSize = 26.sp, fontWeight = FontWeight.Medium)
        }
    }
}
