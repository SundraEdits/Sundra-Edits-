package com.sundraedits.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sundraedits.app.data.*
import kotlinx.coroutines.flow.*

data class Stats(
    val revenue: Long = 0, val outstanding: Long = 0, val expenses: Long = 0,
    val totalInvoices: Int = 0, val paid: Int = 0, val pending: Int = 0, val overdue: Int = 0
) { val net get() = revenue - expenses }

class DashboardViewModel(app: Application) : AndroidViewModel(app) {
    private val db = AppDb.get(app)
    private val currency = MutableStateFlow("INR")
    val selected: StateFlow<String> = currency

    fun select(c: String) { currency.value = c }

    /** Each currency is computed separately; INR and USD are never combined. */
    val stats: StateFlow<Stats> = combine(
        db.invoices().all(), db.payments().all(), db.expenses().all(), currency
    ) { inv, pay, exp, cur ->
        val now = System.currentTimeMillis()
        val invs = inv.filter { it.currency == cur }
        val paidByInvoice = pay.filter { it.currency == cur }.groupBy { it.invoiceId }
            .mapValues { e -> e.value.sumOf { it.amountMinor } }
        val live = invs.filter { it.status != "Cancelled" && it.status != "Draft" }
        val outstanding = live.sumOf { (it.totalMinor - (paidByInvoice[it.id] ?: 0)).coerceAtLeast(0) }
        Stats(
            revenue = pay.filter { it.currency == cur }.sumOf { it.amountMinor },
            outstanding = outstanding,
            expenses = exp.filter { it.currency == cur }.sumOf { it.amountMinor },
            totalInvoices = invs.size,
            paid = live.count { it.status == "Paid" },
            pending = live.count { it.status == "Pending" || it.status == "Partial" },
            overdue = live.count {
                it.status != "Paid" && it.dueDate < now && (it.totalMinor - (paidByInvoice[it.id] ?: 0)) > 0
            }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Stats())
}
