# SUNDRA EDITS App — Phase 1

Status: Phase 1 only (project setup, Room database, theme, navigation, dashboard).
This code has NOT been compiled or tested by its author. Expect possible build errors.

## Get the APK from your phone
1. Create a free account at github.com and make a new repository.
2. Upload the contents of this folder (keep the `.github` folder).
3. Open the repo > Actions > "Build APK" > Run workflow (it also runs on push to main).
4. When it finishes, open the run and download the `SundraEdits-debug-apk` artifact.
5. Unzip it, open the .apk, allow "install unknown apps" when asked.

If the build fails, send me the red error text from the log.

## Not built yet
Clients, services, invoices, payments, expenses, quotations, analytics, PDF,
WhatsApp sharing, backup/restore, settings, charts, recycle bin.
